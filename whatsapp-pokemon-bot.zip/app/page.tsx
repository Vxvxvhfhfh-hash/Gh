"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Wifi, WifiOff, Zap, Play, Square, Phone, MessageCircle, Send, Download } from "lucide-react"

interface BotStatus {
  isConnected: boolean
  status: string
  qrCode?: string
  pairingCode?: string
}

export default function WhatsAppBot() {
  const [botStatus, setBotStatus] = useState<BotStatus>({
    isConnected: false,
    status: "Déconnecté",
  })
  const [phoneNumber, setPhoneNumber] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [testCommand, setTestCommand] = useState("")
  const [chatHistory, setChatHistory] = useState<Array<{ type: "command" | "response"; text: string; time: string }>>(
    [],
  )

  useEffect(() => {
    checkBotStatus()
    const interval = setInterval(checkBotStatus, 2000)
    return () => clearInterval(interval)
  }, [])

  const checkBotStatus = async () => {
    try {
      const response = await fetch("/api/bot/status")
      if (response.ok) {
        const data = await response.json()
        setBotStatus(data)
      }
    } catch (error) {
      console.error("Erreur status:", error)
    }
  }

  const startBot = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/bot/start", { method: "POST" })
      const data = await response.json()

      if (response.ok) {
        setBotStatus((prev) => ({ ...prev, status: "Démarrage..." }))
      } else {
        alert("Erreur: " + data.error)
      }
    } catch (error) {
      console.error("Erreur démarrage:", error)
      alert("Erreur de connexion. Vérifiez votre connexion internet.")
    }
    setIsLoading(false)
  }

  const stopBot = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/bot/stop", { method: "POST" })
      if (response.ok) {
        setBotStatus({ isConnected: false, status: "Déconnecté" })
        setChatHistory([])
      }
    } catch (error) {
      console.error("Erreur arrêt:", error)
    }
    setIsLoading(false)
  }

  const requestPairingCode = async () => {
    if (!phoneNumber) {
      alert("Veuillez entrer un numéro de téléphone")
      return
    }

    const phoneRegex = /^\+[1-9]\d{1,14}$/
    if (!phoneRegex.test(phoneNumber)) {
      alert("Format invalide. Utilisez le format international (+33123456789)")
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch("/api/bot/pairing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phoneNumber }),
      })

      const data = await response.json()

      if (response.ok) {
        setBotStatus((prev) => ({
          ...prev,
          pairingCode: data.code,
          status: "Code de jumelage généré",
        }))
      } else {
        alert("Erreur: " + data.error)
      }
    } catch (error) {
      console.error("Erreur code:", error)
      alert("Erreur de connexion. Vérifiez votre connexion internet.")
    }
    setIsLoading(false)
  }

  const testBotCommand = async () => {
    if (!testCommand.trim()) return

    const command = testCommand.startsWith("!") ? testCommand : "!" + testCommand

    try {
      const response = await fetch("/api/bot/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command }),
      })

      const data = await response.json()
      const time = new Date().toLocaleTimeString()

      setChatHistory((prev) => [
        ...prev,
        { type: "command", text: command, time },
        { type: "response", text: data.response || data.error, time },
      ])

      setTestCommand("")
    } catch (error) {
      console.error("Erreur test:", error)
      const time = new Date().toLocaleTimeString()
      setChatHistory((prev) => [...prev, { type: "response", text: "Erreur de connexion", time }])
    }
  }

  const quickCommands = ["!start", "!catch", "!pokemon", "!profile", "!wild", "!bag", "!shop", "!help"]

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold text-gray-900 flex items-center justify-center gap-2">
            <Zap className="text-yellow-500" />
            PokéBot WhatsApp
          </h1>
          <p className="text-gray-600">Bot WhatsApp avec système Pokémon complet</p>
          <div className="flex justify-center gap-2">
            <Badge variant="outline" className="bg-blue-50">
              ✅ Version démo fonctionnelle
            </Badge>
            <Badge variant="outline" className="bg-green-50">
              🎮 25+ commandes Pokémon
            </Badge>
          </div>
        </div>

        {/* Alerte de production */}
        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <Download className="text-orange-600 mt-1" size={20} />
              <div>
                <h3 className="font-semibold text-orange-800">Pour utiliser avec le vrai WhatsApp :</h3>
                <p className="text-sm text-orange-700 mt-1">
                  Cette version est une démo. Pour connecter le vrai WhatsApp, téléchargez le code et installez les
                  dépendances <code>whatsapp-web.js</code> et <code>puppeteer</code> sur votre serveur.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Colonne gauche - Contrôles */}
          <div className="space-y-6">
            {/* Statut de connexion */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {botStatus.isConnected ? <Wifi className="text-green-500" /> : <WifiOff className="text-red-500" />}
                  Statut du bot
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Badge variant={botStatus.isConnected ? "default" : "secondary"} className="text-sm">
                  {botStatus.status}
                </Badge>

                <div className="flex gap-2">
                  <Button onClick={startBot} disabled={botStatus.isConnected || isLoading} className="flex-1">
                    <Play className="w-4 h-4 mr-2" />
                    {isLoading ? "..." : "Démarrer"}
                  </Button>
                  <Button
                    onClick={stopBot}
                    disabled={!botStatus.isConnected || isLoading}
                    variant="outline"
                    className="flex-1"
                  >
                    <Square className="w-4 h-4 mr-2" />
                    Arrêter
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Code de jumelage */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Phone />
                  Code de jumelage
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    type="tel"
                    placeholder="+33123456789"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="flex-1"
                  />
                  <Button onClick={requestPairingCode} disabled={!phoneNumber || isLoading}>
                    Générer
                  </Button>
                </div>

                {botStatus.pairingCode && (
                  <div className="text-center p-4 bg-blue-50 rounded-lg border">
                    <p className="text-sm text-gray-600 mb-2">Code de jumelage:</p>
                    <p className="text-2xl font-mono font-bold text-blue-600">{botStatus.pairingCode}</p>
                    <p className="text-xs text-gray-500 mt-2">Code simulé pour la démo</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Colonne centrale - QR Code */}
          <div className="space-y-6">
            {botStatus.qrCode && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-center">QR Code WhatsApp</CardTitle>
                </CardHeader>
                <CardContent className="flex justify-center">
                  <div className="bg-white p-4 rounded-lg shadow-lg border">
                    <img src={botStatus.qrCode || "/placeholder.svg"} alt="QR Code" className="w-48 h-48" />
                    <p className="text-center text-xs text-gray-500 mt-2">QR Code simulé pour la démo</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Test du bot */}
            {botStatus.isConnected && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageCircle />
                    Test des commandes
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Tapez une commande (ex: start)"
                      value={testCommand}
                      onChange={(e) => setTestCommand(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && testBotCommand()}
                      className="flex-1"
                    />
                    <Button onClick={testBotCommand} disabled={!testCommand.trim()}>
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {quickCommands.map((cmd) => (
                      <Button
                        key={cmd}
                        variant="outline"
                        size="sm"
                        onClick={() => setTestCommand(cmd.substring(1))}
                        className="text-xs"
                      >
                        {cmd}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Colonne droite - Chat */}
          <div className="space-y-6">
            {botStatus.isConnected && (
              <Card className="h-96">
                <CardHeader>
                  <CardTitle>💬 Chat de test</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 overflow-y-auto space-y-2 mb-4 p-2 bg-gray-50 rounded">
                    {chatHistory.length === 0 ? (
                      <div className="text-center text-gray-500 text-sm py-8">
                        <p>🎮 Testez les commandes Pokémon ici !</p>
                        <p className="text-xs mt-2">Commencez par !start</p>
                      </div>
                    ) : (
                      chatHistory.map((msg, index) => (
                        <div
                          key={index}
                          className={`p-2 rounded text-sm ${
                            msg.type === "command" ? "bg-blue-100 text-blue-800 ml-8" : "bg-white text-gray-800 mr-8"
                          }`}
                        >
                          <div className="font-mono text-xs text-gray-500 mb-1">{msg.time}</div>
                          <div className="whitespace-pre-wrap">{msg.text}</div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Guide d'utilisation */}
        <Card>
          <CardHeader>
            <CardTitle>🎮 Guide d'utilisation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <h4 className="font-semibold text-green-600 mb-2">📱 1. Test de la démo</h4>
                <ul className="text-sm space-y-1 text-gray-600">
                  <li>• Cliquez sur "Démarrer le bot"</li>
                  <li>• Attendez la connexion (5 sec)</li>
                  <li>• Utilisez la section "Test des commandes"</li>
                  <li>
                    • Commencez par <code>!start</code>
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold text-blue-600 mb-2">🎯 2. Commandes Pokémon</h4>
                <ul className="text-sm space-y-1 text-gray-600">
                  <li>
                    • <code>!catch</code> - Capturer des Pokémon
                  </li>
                  <li>
                    • <code>!wild</code> - Combat sauvage
                  </li>
                  <li>
                    • <code>!shop</code> - Acheter des objets
                  </li>
                  <li>
                    • <code>!help</code> - Voir toutes les commandes
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold text-purple-600 mb-2">🚀 3. Production</h4>
                <ul className="text-sm space-y-1 text-gray-600">
                  <li>• Téléchargez le code complet</li>
                  <li>• Installez whatsapp-web.js</li>
                  <li>• Déployez sur votre serveur</li>
                  <li>• Connectez le vrai WhatsApp</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Commandes disponibles */}
        <Card>
          <CardHeader>
            <CardTitle>⚡ Toutes les commandes Pokémon (25+)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
              <div className="space-y-2">
                <h4 className="font-semibold text-green-600">🎮 Jeu de base</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>
                    <code>!start</code> - Commencer
                  </li>
                  <li>
                    <code>!profile</code> - Profil
                  </li>
                  <li>
                    <code>!catch</code> - Capturer
                  </li>
                  <li>
                    <code>!pokemon</code> - Collection
                  </li>
                  <li>
                    <code>!release [nom]</code> - Relâcher
                  </li>
                </ul>
              </div>

              <div className="space-y-2">
                <h4 className="font-semibold text-red-600">⚔️ Combat</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>
                    <code>!wild</code> - Combat sauvage
                  </li>
                  <li>
                    <code>!battle @user</code> - Défier*
                  </li>
                  <li>
                    <code>!accept</code> - Accepter*
                  </li>
                  <li>
                    <code>!attack [move]</code> - Attaquer*
                  </li>
                </ul>
                <p className="text-xs text-gray-400">*PvP en production</p>
              </div>

              <div className="space-y-2">
                <h4 className="font-semibold text-blue-600">🎒 Inventaire</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>
                    <code>!bag</code> - Sac
                  </li>
                  <li>
                    <code>!use [item]</code> - Utiliser
                  </li>
                  <li>
                    <code>!shop</code> - Boutique
                  </li>
                  <li>
                    <code>!buy [item]</code> - Acheter
                  </li>
                </ul>
              </div>

              <div className="space-y-2">
                <h4 className="font-semibold text-purple-600">📊 Stats</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>
                    <code>!stats [pokemon]</code> - Stats
                  </li>
                  <li>
                    <code>!leaderboard</code> - Classement
                  </li>
                  <li>
                    <code>!trade @user</code> - Échanger*
                  </li>
                  <li>
                    <code>!help</code> - Aide
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
