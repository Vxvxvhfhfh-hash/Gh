import { NextResponse } from "next/server"

let botInstance: any = null
let isStarting = false

export async function POST() {
  try {
    if (isStarting) {
      return NextResponse.json({ error: "Bot en cours de démarrage..." }, { status: 400 })
    }

    if (botInstance) {
      return NextResponse.json({ error: "Bot déjà démarré" }, { status: 400 })
    }

    isStarting = true

    // Import dynamique pour éviter les erreurs SSR
    const { startBot } = await import("@/lib/bot-manager")

    botInstance = await startBot()
    isStarting = false

    return NextResponse.json({ success: true, message: "Bot démarré avec succès" })
  } catch (error) {
    isStarting = false
    console.error("Erreur démarrage bot:", error)
    return NextResponse.json(
      {
        error: "Erreur lors du démarrage du bot: " + error.message,
      },
      { status: 500 },
    )
  }
}

export { botInstance }
