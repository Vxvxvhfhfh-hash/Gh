import { NextResponse } from "next/server"

export async function POST() {
  try {
    const { stopBot } = await import("@/lib/bot-manager")
    await stopBot()

    return NextResponse.json({ success: true, message: "Bot arrêté" })
  } catch (error) {
    console.error("Erreur arrêt bot:", error)
    return NextResponse.json({ error: "Erreur lors de l'arrêt du bot" }, { status: 500 })
  }
}
