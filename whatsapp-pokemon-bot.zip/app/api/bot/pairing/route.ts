import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { phoneNumber } = await request.json()

    if (!phoneNumber) {
      return NextResponse.json({ error: "Numéro de téléphone requis" }, { status: 400 })
    }

    // Validation du format du numéro
    const phoneRegex = /^\+[1-9]\d{1,14}$/
    if (!phoneRegex.test(phoneNumber)) {
      return NextResponse.json(
        {
          error: "Format de numéro invalide. Utilisez le format international (+33123456789)",
        },
        { status: 400 },
      )
    }

    const { requestPairingCode, getClient } = await import("@/lib/bot-manager")

    // Vérifier si le bot est démarré
    const client = getClient()
    if (!client) {
      return NextResponse.json(
        {
          error: "Bot non démarré. Cliquez d'abord sur 'Démarrer le bot'",
        },
        { status: 400 },
      )
    }

    const code = await requestPairingCode(phoneNumber)

    return NextResponse.json({ success: true, code })
  } catch (error) {
    console.error("Erreur code jumelage:", error)
    return NextResponse.json(
      {
        error: error.message || "Erreur lors de la génération du code",
      },
      { status: 500 },
    )
  }
}
