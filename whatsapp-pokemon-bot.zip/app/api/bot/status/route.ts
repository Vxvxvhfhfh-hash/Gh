import { NextResponse } from "next/server"

// Stockage en mémoire pour le statut du bot
let botStatus = {
  isConnected: false,
  status: "Déconnecté",
  qrCode: undefined as string | undefined,
  pairingCode: undefined as string | undefined,
}

export async function GET() {
  return NextResponse.json(botStatus)
}

export function updateBotStatus(newStatus: Partial<typeof botStatus>) {
  botStatus = { ...botStatus, ...newStatus }
}

export function getBotStatus() {
  return botStatus
}
