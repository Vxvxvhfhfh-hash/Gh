import type { NextRequest } from "next/server"
import { getEventStream } from "@/lib/whatsapp-bot"

export async function GET(request: NextRequest) {
  const stream = getEventStream()

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  })
}
