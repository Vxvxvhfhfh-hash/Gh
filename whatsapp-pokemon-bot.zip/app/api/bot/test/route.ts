import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { command } = await request.json()

    if (!command) {
      return NextResponse.json({ error: "Commande requise" }, { status: 400 })
    }

    const { processCommand } = await import("@/lib/bot-manager")
    const response = await processCommand(command)

    return NextResponse.json({ success: true, response })
  } catch (error) {
    console.error("Erreur test commande:", error)
    return NextResponse.json(
      {
        error: "Erreur lors du test: " + error.message,
      },
      { status: 500 },
    )
  }
}
