interface Pokemon {
  id: number
  name: string
  type: string[]
  level: number
  hp: number
  maxHp: number
  attack: number
  defense: number
  moves: string[]
  experience: number
  shiny: boolean
}

interface Player {
  id: string
  name: string
  pokemon: Pokemon[]
  items: { [key: string]: number }
  money: number
  badges: number
  wins: number
  losses: number
  activePokemon?: Pokemon
}

interface Battle {
  player1: string
  player2: string
  turn: string
  pokemon1: Pokemon
  pokemon2: Pokemon
  status: "waiting" | "active" | "finished"
}

export class PokemonGame {
  private players: Map<string, Player> = new Map()
  private battles: Map<string, Battle> = new Map()
  private challenges: Map<string, string> = new Map()

  private pokemonData = [
    {
      id: 1,
      name: "Pikachu",
      type: ["Électrik"],
      baseHp: 35,
      baseAttack: 55,
      baseDef: 40,
      moves: ["Éclair", "Vive-Attaque", "Tonnerre", "Fatal-Foudre"],
    },
    {
      id: 2,
      name: "Salamèche",
      type: ["Feu"],
      baseHp: 39,
      baseAttack: 52,
      baseDef: 43,
      moves: ["Griffe", "Flammèche", "Lance-Flammes", "Déflagration"],
    },
    {
      id: 3,
      name: "Carapuce",
      type: ["Eau"],
      baseHp: 44,
      baseAttack: 48,
      baseDef: 65,
      moves: ["Charge", "Pistolet à O", "Hydrocanon", "Surf"],
    },
    {
      id: 4,
      name: "Bulbizarre",
      type: ["Plante", "Poison"],
      baseHp: 45,
      baseAttack: 49,
      baseDef: 49,
      moves: ["Charge", "Fouet Lianes", "Lance-Soleil", "Poudre Toxik"],
    },
    {
      id: 5,
      name: "Roucool",
      type: ["Normal", "Vol"],
      baseHp: 40,
      baseAttack: 45,
      baseDef: 40,
      moves: ["Charge", "Tornade", "Vive-Attaque", "Ouragan"],
    },
    {
      id: 6,
      name: "Rattata",
      type: ["Normal"],
      baseHp: 30,
      baseAttack: 56,
      baseDef: 35,
      moves: ["Charge", "Vive-Attaque", "Croc de Mort", "Effort"],
    },
    {
      id: 7,
      name: "Évoli",
      type: ["Normal"],
      baseHp: 55,
      baseAttack: 55,
      baseDef: 50,
      moves: ["Charge", "Vive-Attaque", "Morsure", "Bélier"],
    },
    {
      id: 8,
      name: "Magicarpe",
      type: ["Eau"],
      baseHp: 20,
      baseAttack: 10,
      baseDef: 55,
      moves: ["Trempette", "Charge"],
    },
    {
      id: 9,
      name: "Dracaufeu",
      type: ["Feu", "Vol"],
      baseHp: 78,
      baseAttack: 84,
      baseDef: 78,
      moves: ["Griffe", "Lance-Flammes", "Vol", "Colère du Dragon"],
    },
    {
      id: 10,
      name: "Mewtwo",
      type: ["Psy"],
      baseHp: 106,
      baseAttack: 110,
      baseDef: 90,
      moves: ["Psyko", "Psycho-Boost", "Ball'Ombre", "Régénération"],
    },
  ]

  private items = {
    Potion: { price: 200, description: "Restaure 20 HP" },
    "Super Potion": { price: 700, description: "Restaure 50 HP" },
    "Hyper Potion": { price: 1200, description: "Restaure 200 HP" },
    Pokéball: { price: 200, description: "Capture un Pokémon" },
    "Super Ball": { price: 600, description: "Meilleure capture" },
    "Hyper Ball": { price: 1200, description: "Excellente capture" },
    Rappel: { price: 1500, description: "Ranime un Pokémon KO" },
    Antidote: { price: 100, description: "Soigne l'empoisonnement" },
  }

  startPlayer(userId: string, userName: string): string {
    if (this.players.has(userId)) {
      return `🎮 ${userName}, vous avez déjà commencé votre aventure Pokémon!`
    }

    // Pokémon de départ aléatoire
    const starters = [1, 2, 3, 4] // Pikachu, Salamèche, Carapuce, Bulbizarre
    const starterId = starters[Math.floor(Math.random() * starters.length)]
    const starterPokemon = this.generatePokemon(starterId, 5)

    const newPlayer: Player = {
      id: userId,
      name: userName,
      pokemon: [starterPokemon],
      items: {
        Potion: 5,
        Pokéball: 10,
      },
      money: 1000,
      badges: 0,
      wins: 0,
      losses: 0,
      activePokemon: starterPokemon,
    }

    this.players.set(userId, newPlayer)

    return `🎉 *Bienvenue dans le monde Pokémon, ${userName}!*

🌟 Votre Pokémon de départ: *${starterPokemon.name}* ${starterPokemon.shiny ? "✨" : ""}
📊 Niveau: ${starterPokemon.level}
❤️ HP: ${starterPokemon.hp}/${starterPokemon.maxHp}
💰 Argent: ${newPlayer.money} ₽

🎒 Objets de départ:
• 5x Potion
• 10x Pokéball

Tapez !help pour voir toutes les commandes disponibles!`
  }

  getProfile(userId: string): string {
    const player = this.players.get(userId)
    if (!player) {
      return "❌ Vous devez d'abord commencer votre aventure avec !start"
    }

    const totalPokemon = player.pokemon.length
    const shinyCount = player.pokemon.filter((p) => p.shiny).length
    const avgLevel = Math.round(player.pokemon.reduce((sum, p) => sum + p.level, 0) / totalPokemon)

    return `👤 *Profil de ${player.name}*

🏆 Victoires: ${player.wins} | Défaites: ${player.losses}
🎖️ Badges: ${player.badges}
💰 Argent: ${player.money} ₽

📊 *Collection Pokémon:*
• Total: ${totalPokemon} Pokémon
• Shiny: ${shinyCount} ✨
• Niveau moyen: ${avgLevel}

🎯 *Pokémon actif:* ${player.activePokemon?.name || "Aucun"} ${player.activePokemon?.shiny ? "✨" : ""}
❤️ HP: ${player.activePokemon?.hp || 0}/${player.activePokemon?.maxHp || 0}`
  }

  catchPokemon(userId: string): string {
    const player = this.players.get(userId)
    if (!player) {
      return "❌ Vous devez d'abord commencer votre aventure avec !start"
    }

    if (!player.items["Pokéball"] || player.items["Pokéball"] <= 0) {
      return "❌ Vous n'avez plus de Pokéball! Achetez-en à la boutique avec !shop"
    }

    // Pokémon aléatoire avec rareté
    const commonPokemon = [1, 2, 3, 4, 5, 6] // 70%
    const rarePokemon = [7, 8] // 25%
    const legendaryPokemon = [9, 10] // 5%

    let pokemonId: number
    const rarity = Math.random()

    if (rarity < 0.7) {
      pokemonId = commonPokemon[Math.floor(Math.random() * commonPokemon.length)]
    } else if (rarity < 0.95) {
      pokemonId = rarePokemon[Math.floor(Math.random() * rarePokemon.length)]
    } else {
      pokemonId = legendaryPokemon[Math.floor(Math.random() * legendaryPokemon.length)]
    }

    const level = Math.floor(Math.random() * 20) + 1
    const newPokemon = this.generatePokemon(pokemonId, level)

    // Chance de capture basée sur la rareté
    let catchRate = 0.8
    if (legendaryPokemon.includes(pokemonId)) catchRate = 0.3
    else if (rarePokemon.includes(pokemonId)) catchRate = 0.6

    player.items["Pokéball"]--

    if (Math.random() < catchRate) {
      player.pokemon.push(newPokemon)
      this.players.set(userId, player)

      return `🎉 *Capture réussie!*

${newPokemon.shiny ? "✨ " : ""}*${newPokemon.name}* a été capturé!
📊 Niveau: ${newPokemon.level}
❤️ HP: ${newPokemon.hp}/${newPokemon.maxHp}
🔥 Attaque: ${newPokemon.attack}
🛡️ Défense: ${newPokemon.defense}
${newPokemon.shiny ? "\n🌟 C'est un Pokémon Shiny! Très rare!" : ""}

🎒 Pokéball restantes: ${player.items["Pokéball"]}`
    } else {
      return `💨 *${this.pokemonData.find((p) => p.id === pokemonId)?.name}* s'est échappé!

🎒 Pokéball restantes: ${player.items["Pokéball"]}
💡 Astuce: Les Super Ball ont un meilleur taux de capture!`
    }
  }

  getPokemonList(userId: string): string {
    const player = this.players.get(userId)
    if (!player) {
      return "❌ Vous devez d'abord commencer votre aventure avec !start"
    }

    if (player.pokemon.length === 0) {
      return "📦 Vous n'avez aucun Pokémon. Utilisez !catch pour en capturer!"
    }

    let pokemonList = `🎒 *Collection de ${player.name}* (${player.pokemon.length} Pokémon)\n\n`

    player.pokemon.forEach((pokemon, index) => {
      const isActive = player.activePokemon?.name === pokemon.name
      pokemonList += `${index + 1}. ${pokemon.shiny ? "✨ " : ""}*${pokemon.name}* ${isActive ? "(Actif)" : ""}\n`
      pokemonList += `   📊 Niv.${pokemon.level} | ❤️ ${pokemon.hp}/${pokemon.maxHp} HP\n`
      pokemonList += `   🔥 ATK: ${pokemon.attack} | 🛡️ DEF: ${pokemon.defense}\n\n`
    })

    return pokemonList
  }

  challengePlayer(challengerId: string, targetId: string): string {
    const challenger = this.players.get(challengerId)
    const target = this.players.get(targetId)

    if (!challenger || !target) {
      return "❌ L'un des joueurs n'a pas encore commencé son aventure Pokémon!"
    }

    if (!challenger.activePokemon || challenger.activePokemon.hp <= 0) {
      return "❌ Votre Pokémon actif est KO! Soignez-le d'abord."
    }

    if (!target.activePokemon || target.activePokemon.hp <= 0) {
      return "❌ Le Pokémon de votre adversaire est KO!"
    }

    this.challenges.set(targetId, challengerId)

    return `⚔️ *Défi de combat lancé!*

${challenger.name} défie ${target.name}!

🔥 ${challenger.activePokemon.name} ${challenger.activePokemon.shiny ? "✨" : ""} (Niv.${challenger.activePokemon.level})
VS
🔥 ${target.activePokemon.name} ${target.activePokemon.shiny ? "✨" : ""} (Niv.${target.activePokemon.level})

${target.name}, tapez !accept pour accepter le défi!`
  }

  acceptBattle(userId: string): string {
    const challengerId = this.challenges.get(userId)
    if (!challengerId) {
      return "❌ Vous n'avez aucun défi en attente!"
    }

    const challenger = this.players.get(challengerId)
    const defender = this.players.get(userId)

    if (!challenger || !defender) {
      return "❌ Erreur lors de l'initialisation du combat!"
    }

    const battleId = `${challengerId}_${userId}`
    const battle: Battle = {
      player1: challengerId,
      player2: userId,
      turn: challengerId,
      pokemon1: { ...challenger.activePokemon! },
      pokemon2: { ...defender.activePokemon! },
      status: "active",
    }

    this.battles.set(battleId, battle)
    this.challenges.delete(userId)

    return `⚔️ *COMBAT POKÉMON COMMENCE!*

🔥 ${challenger.name}: ${battle.pokemon1.name} ${battle.pokemon1.shiny ? "✨" : ""}
   ❤️ HP: ${battle.pokemon1.hp}/${battle.pokemon1.maxHp}

🔥 ${defender.name}: ${battle.pokemon2.name} ${battle.pokemon2.shiny ? "✨" : ""}
   ❤️ HP: ${battle.pokemon2.hp}/${battle.pokemon2.maxHp}

🎯 C'est au tour de ${challenger.name}!
Utilisez !attack [nom_attaque] pour attaquer!

💡 Attaques disponibles: ${battle.pokemon1.moves.join(", ")}`
  }

  attack(userId: string, moveName: string): string {
    // Trouver le combat actif
    let currentBattle: Battle | null = null
    let battleId = ""

    for (const [id, battle] of this.battles.entries()) {
      if ((battle.player1 === userId || battle.player2 === userId) && battle.status === "active") {
        currentBattle = battle
        battleId = id
        break
      }
    }

    if (!currentBattle) {
      return "❌ Vous n'êtes dans aucun combat actif!"
    }

    if (currentBattle.turn !== userId) {
      return "❌ Ce n'est pas votre tour!"
    }

    const isPlayer1 = currentBattle.player1 === userId
    const attackingPokemon = isPlayer1 ? currentBattle.pokemon1 : currentBattle.pokemon2
    const defendingPokemon = isPlayer1 ? currentBattle.pokemon2 : currentBattle.pokemon1

    if (!attackingPokemon.moves.includes(moveName)) {
      return `❌ ${attackingPokemon.name} ne connaît pas cette attaque!\n💡 Attaques disponibles: ${attackingPokemon.moves.join(", ")}`
    }

    // Calcul des dégâts
    const baseDamage = Math.floor(Math.random() * 20) + 10
    const damage = Math.max(1, baseDamage + attackingPokemon.attack - defendingPokemon.defense)

    defendingPokemon.hp = Math.max(0, defendingPokemon.hp - damage)

    let result = `⚔️ *${attackingPokemon.name}* utilise *${moveName}*!\n`
    result += `💥 ${damage} dégâts infligés!\n\n`
    result += `❤️ ${defendingPokemon.name}: ${defendingPokemon.hp}/${defendingPokemon.maxHp} HP\n`

    // Vérifier si le combat est terminé
    if (defendingPokemon.hp <= 0) {
      const winner = this.players.get(userId)!
      const loser = this.players.get(isPlayer1 ? currentBattle.player2 : currentBattle.player1)!

      winner.wins++
      winner.money += 500
      loser.losses++

      // Mettre à jour les HP des Pokémon réels
      if (isPlayer1) {
        loser.activePokemon!.hp = 0
      } else {
        winner.activePokemon!.hp = 0
      }

      this.players.set(winner.id, winner)
      this.players.set(loser.id, loser)
      this.battles.delete(battleId)

      result += `\n🏆 *${winner.name} remporte le combat!*\n`
      result += `💰 +500 ₽ de récompense!\n`
      result += `📊 ${winner.name}: ${winner.wins}V-${winner.losses}D`

      return result
    }

    // Changer de tour
    currentBattle.turn = isPlayer1 ? currentBattle.player2 : currentBattle.player1
    this.battles.set(battleId, currentBattle)

    const nextPlayer = this.players.get(currentBattle.turn)!
    const nextPokemon = isPlayer1 ? currentBattle.pokemon2 : currentBattle.pokemon1

    result += `\n🎯 Au tour de ${nextPlayer.name}!\n`
    result += `💡 Attaques: ${nextPokemon.moves.join(", ")}`

    return result
  }

  wildBattle(userId: string): string {
    const player = this.players.get(userId)
    if (!player || !player.activePokemon || player.activePokemon.hp <= 0) {
      return "❌ Votre Pokémon actif est KO! Soignez-le d'abord."
    }

    const wildPokemonId = Math.floor(Math.random() * this.pokemonData.length) + 1
    const wildLevel = Math.floor(Math.random() * 15) + 1
    const wildPokemon = this.generatePokemon(wildPokemonId, wildLevel)

    // Combat automatique simplifié
    const playerPower = player.activePokemon.level * player.activePokemon.attack
    const wildPower = wildPokemon.level * wildPokemon.attack

    const winChance = playerPower / (playerPower + wildPower)
    const won = Math.random() < winChance

    if (won) {
      const expGain = Math.floor(wildPokemon.level * 1.5)
      const moneyGain = Math.floor(wildPokemon.level * 10)

      player.activePokemon.experience += expGain
      player.money += moneyGain

      // Chance de level up
      if (player.activePokemon.experience >= player.activePokemon.level * 100) {
        player.activePokemon.level++
        player.activePokemon.experience = 0
        player.activePokemon.maxHp += 5
        player.activePokemon.hp = player.activePokemon.maxHp
        player.activePokemon.attack += 2
        player.activePokemon.defense += 2
      }

      this.players.set(userId, player)

      return `🏆 *Victoire contre ${wildPokemon.name} sauvage!*

📊 ${wildPokemon.name} Niv.${wildPokemon.level} vaincu!
✨ +${expGain} EXP
💰 +${moneyGain} ₽

🔥 ${player.activePokemon.name}:
   📊 Niv.${player.activePokemon.level} | EXP: ${player.activePokemon.experience}/${player.activePokemon.level * 100}
   ❤️ HP: ${player.activePokemon.hp}/${player.activePokemon.maxHp}`
    } else {
      const damage = Math.floor(wildPokemon.attack / 2)
      player.activePokemon.hp = Math.max(0, player.activePokemon.hp - damage)
      this.players.set(userId, player)

      return `💥 *Défaite contre ${wildPokemon.name} sauvage!*

😵 ${player.activePokemon.name} a subi ${damage} dégâts!
❤️ HP restants: ${player.activePokemon.hp}/${player.activePokemon.maxHp}

💡 Entraînez-vous encore ou soignez votre Pokémon!`
    }
  }

  getBag(userId: string): string {
    const player = this.players.get(userId)
    if (!player) {
      return "❌ Vous devez d'abord commencer votre aventure avec !start"
    }

    let bagContent = `🎒 *Sac de ${player.name}*\n💰 Argent: ${player.money} ₽\n\n`

    if (Object.keys(player.items).length === 0) {
      return bagContent + "📦 Votre sac est vide! Achetez des objets avec !shop"
    }

    for (const [item, quantity] of Object.entries(player.items)) {
      if (quantity > 0) {
        bagContent += `• ${item}: ${quantity}x\n`
      }
    }

    bagContent += "\n💡 Utilisez !use [objet] pour utiliser un objet"

    return bagContent
  }

  useItem(userId: string, itemName: string): string {
    const player = this.players.get(userId)
    if (!player) {
      return "❌ Vous devez d'abord commencer votre aventure avec !start"
    }

    if (!player.items[itemName] || player.items[itemName] <= 0) {
      return `❌ Vous n'avez pas de ${itemName}!`
    }

    if (!player.activePokemon) {
      return "❌ Aucun Pokémon actif!"
    }

    let result = ""

    switch (itemName) {
      case "Potion":
        if (player.activePokemon.hp >= player.activePokemon.maxHp) {
          return "❌ Votre Pokémon a déjà tous ses HP!"
        }
        player.activePokemon.hp = Math.min(player.activePokemon.maxHp, player.activePokemon.hp + 20)
        result = `💊 ${player.activePokemon.name} récupère 20 HP!`
        break

      case "Super Potion":
        if (player.activePokemon.hp >= player.activePokemon.maxHp) {
          return "❌ Votre Pokémon a déjà tous ses HP!"
        }
        player.activePokemon.hp = Math.min(player.activePokemon.maxHp, player.activePokemon.hp + 50)
        result = `💊 ${player.activePokemon.name} récupère 50 HP!`
        break

      case "Hyper Potion":
        if (player.activePokemon.hp >= player.activePokemon.maxHp) {
          return "❌ Votre Pokémon a déjà tous ses HP!"
        }
        player.activePokemon.hp = Math.min(player.activePokemon.maxHp, player.activePokemon.hp + 200)
        result = `💊 ${player.activePokemon.name} récupère 200 HP!`
        break

      case "Rappel":
        if (player.activePokemon.hp > 0) {
          return "❌ Votre Pokémon n'est pas KO!"
        }
        player.activePokemon.hp = Math.floor(player.activePokemon.maxHp / 2)
        result = `🔄 ${player.activePokemon.name} est ranimé avec ${player.activePokemon.hp} HP!`
        break

      default:
        return `❌ Impossible d'utiliser ${itemName}!`
    }

    player.items[itemName]--
    this.players.set(userId, player)

    result += `\n❤️ HP: ${player.activePokemon.hp}/${player.activePokemon.maxHp}`
    result += `\n🎒 ${itemName} restants: ${player.items[itemName]}`

    return result
  }

  getShop(): string {
    let shop = `🏪 *BOUTIQUE POKÉMON*\n\n`

    for (const [item, info] of Object.entries(this.items)) {
      shop += `💰 *${item}* - ${info.price} ₽\n`
      shop += `   ${info.description}\n\n`
    }

    shop += `💡 Utilisez !buy [objet] pour acheter\n`
    shop += `💰 Consultez votre argent avec !profile`

    return shop
  }

  buyItem(userId: string, itemName: string): string {
    const player = this.players.get(userId)
    if (!player) {
      return "❌ Vous devez d'abord commencer votre aventure avec !start"
    }

    const item = this.items[itemName as keyof typeof this.items]
    if (!item) {
      return `❌ Objet "${itemName}" introuvable! Consultez !shop`
    }

    if (player.money < item.price) {
      return `❌ Pas assez d'argent! ${itemName} coûte ${item.price} ₽\n💰 Vous avez: ${player.money} ₽`
    }

    player.money -= item.price
    player.items[itemName] = (player.items[itemName] || 0) + 1
    this.players.set(userId, player)

    return `🛒 *Achat réussi!*

✅ ${itemName} acheté pour ${item.price} ₽
💰 Argent restant: ${player.money} ₽
🎒 ${itemName}: ${player.items[itemName]}x`
  }

  getPokemonStats(userId: string, pokemonName: string): string {
    const player = this.players.get(userId)
    if (!player) {
      return "❌ Vous devez d'abord commencer votre aventure avec !start"
    }

    const pokemon = player.pokemon.find((p) => p.name.toLowerCase().includes(pokemonName.toLowerCase()))

    if (!pokemon) {
      return `❌ Pokémon "${pokemonName}" introuvable dans votre collection!`
    }

    return `📊 *Statistiques de ${pokemon.name}* ${pokemon.shiny ? "✨" : ""}

🏷️ Type: ${pokemon.type.join(", ")}
📊 Niveau: ${pokemon.level}
✨ EXP: ${pokemon.experience}/${pokemon.level * 100}

💪 *Statistiques:*
❤️ HP: ${pokemon.hp}/${pokemon.maxHp}
🔥 Attaque: ${pokemon.attack}
🛡️ Défense: ${pokemon.defense}

⚔️ *Attaques connues:*
${pokemon.moves.map((move) => `• ${move}`).join("\n")}

${pokemon.shiny ? "🌟 Ce Pokémon est Shiny! Très rare!" : ""}`
  }

  getLeaderboard(): string {
    const sortedPlayers = Array.from(this.players.values())
      .sort((a, b) => b.wins - a.wins)
      .slice(0, 10)

    if (sortedPlayers.length === 0) {
      return "📊 Aucun joueur dans le classement!"
    }

    let leaderboard = `🏆 *CLASSEMENT DES DRESSEURS*\n\n`

    sortedPlayers.forEach((player, index) => {
      const medal = index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `${index + 1}.`
      const winRate =
        player.wins + player.losses > 0 ? Math.round((player.wins / (player.wins + player.losses)) * 100) : 0

      leaderboard += `${medal} *${player.name}*\n`
      leaderboard += `   🏆 ${player.wins}V-${player.losses}D (${winRate}%)\n`
      leaderboard += `   🎖️ ${player.badges} badges | 💰 ${player.money} ₽\n`
      leaderboard += `   📦 ${player.pokemon.length} Pokémon\n\n`
    })

    return leaderboard
  }

  initiateTrade(userId: string, targetId: string): string {
    const player = this.players.get(userId)
    const target = this.players.get(targetId)

    if (!player || !target) {
      return "❌ L'un des joueurs n'a pas encore commencé son aventure!"
    }

    return `🔄 *Système d'échange en développement!*

Cette fonctionnalité sera bientôt disponible.
En attendant, vous pouvez:
• Capturer plus de Pokémon avec !catch
• Combattre d'autres dresseurs avec !battle
• Améliorer vos Pokémon avec !wild`
  }

  releasePokemon(userId: string, pokemonName: string): string {
    const player = this.players.get(userId)
    if (!player) {
      return "❌ Vous devez d'abord commencer votre aventure avec !start"
    }

    if (player.pokemon.length <= 1) {
      return "❌ Vous ne pouvez pas relâcher votre dernier Pokémon!"
    }

    const pokemonIndex = player.pokemon.findIndex((p) => p.name.toLowerCase().includes(pokemonName.toLowerCase()))

    if (pokemonIndex === -1) {
      return `❌ Pokémon "${pokemonName}" introuvable!`
    }

    const releasedPokemon = player.pokemon[pokemonIndex]

    // Si c'est le Pokémon actif, changer pour le premier disponible
    if (player.activePokemon?.name === releasedPokemon.name) {
      player.activePokemon = player.pokemon.find((p) => p.name !== releasedPokemon.name) || null
    }

    player.pokemon.splice(pokemonIndex, 1)
    this.players.set(userId, player)

    return `🕊️ *${releasedPokemon.name}* ${releasedPokemon.shiny ? "✨" : ""} a été relâché dans la nature!

${releasedPokemon.name} sera heureux en liberté.
🎒 Pokémon restants: ${player.pokemon.length}`
  }

  private generatePokemon(id: number, level: number): Pokemon {
    const data = this.pokemonData.find((p) => p.id === id)!
    const isShiny = Math.random() < 0.01 // 1% chance

    const hp = data.baseHp + level * 2
    const attack = data.baseAttack + level
    const defense = data.baseDef + level

    return {
      id: data.id,
      name: data.name,
      type: data.type,
      level,
      hp,
      maxHp: hp,
      attack,
      defense,
      moves: data.moves,
      experience: 0,
      shiny: isShiny,
    }
  }
}
