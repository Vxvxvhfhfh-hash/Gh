import { updateBotStatus } from "@/app/api/bot/status/route"

let client: any = null
let pokemonGame: any = null
let isInitializing = false

// Client WhatsApp simulé pour la démo
class MockWhatsAppClient {
  private eventHandlers: { [key: string]: Function[] } = {}
  private isReady = false

  constructor() {
    // Simuler l'initialisation
  }

  on(event: string, handler: Function) {
    if (!this.eventHandlers[event]) {
      this.eventHandlers[event] = []
    }
    this.eventHandlers[event].push(handler)
  }

  emit(event: string, ...args: any[]) {
    if (this.eventHandlers[event]) {
      this.eventHandlers[event].forEach((handler) => handler(...args))
    }
  }

  async initialize() {
    // Simuler l'initialisation avec QR code
    setTimeout(() => {
      this.emit("qr", "mock-qr-data")
    }, 1000)

    // Simuler la connexion après 5 secondes
    setTimeout(() => {
      this.isReady = true
      this.emit("ready")
    }, 5000)
  }

  async requestPairingCode(phoneNumber: string) {
    // Générer un code de jumelage simulé
    const code = Math.random().toString().substr(2, 8)
    setTimeout(() => {
      this.emit("code", code)
    }, 500)
    return code
  }

  async destroy() {
    this.isReady = false
    this.eventHandlers = {}
  }

  get info() {
    return this.isReady ? { wid: "mock-user" } : null
  }

  get pupPage() {
    return this.isReady
  }
}

export function getClient() {
  return client
}

export function isClientReady() {
  return client && client.info
}

export async function startBot() {
  try {
    if (isInitializing) {
      throw new Error("Bot déjà en cours d'initialisation")
    }

    if (client) {
      await client.destroy()
    }

    isInitializing = true

    // Importer le jeu Pokémon
    const { PokemonGame } = await import("./pokemon-game")
    pokemonGame = new PokemonGame()

    // Créer le client simulé
    client = new MockWhatsAppClient()

    // Événement QR Code
    client.on("qr", async (qr: string) => {
      try {
        const qrCodeDataURL = generateMockQRCode()
        updateBotStatus({
          qrCode: qrCodeDataURL,
          status: "En attente de scan QR",
          pairingCode: undefined,
        })
      } catch (error) {
        console.error("Erreur génération QR:", error)
      }
    })

    // Événement code de jumelage
    client.on("code", (code: string) => {
      updateBotStatus({
        pairingCode: code,
        status: "Code de jumelage généré",
      })
    })

    // Bot prêt
    client.on("ready", () => {
      console.log("✅ Bot WhatsApp connecté!")
      updateBotStatus({
        isConnected: true,
        status: "Connecté et prêt",
        qrCode: undefined,
        pairingCode: undefined,
      })
      isInitializing = false
    })

    updateBotStatus({ status: "Initialisation..." })
    await client.initialize()

    return client
  } catch (error) {
    isInitializing = false
    console.error("Erreur démarrage bot:", error)
    updateBotStatus({
      isConnected: false,
      status: "Erreur de démarrage: " + error.message,
    })
    throw error
  }
}

export async function stopBot() {
  if (client) {
    try {
      await client.destroy()
      client = null
      pokemonGame = null
      isInitializing = false

      updateBotStatus({
        isConnected: false,
        status: "Déconnecté",
        qrCode: undefined,
        pairingCode: undefined,
      })
    } catch (error) {
      console.error("Erreur arrêt bot:", error)
    }
  }
}

export async function requestPairingCode(phoneNumber: string) {
  if (!client) {
    throw new Error("Bot non initialisé. Démarrez d'abord le bot.")
  }

  try {
    if (!client.pupPage && !isInitializing) {
      throw new Error("Bot en cours d'initialisation. Attendez quelques secondes.")
    }

    const code = await client.requestPairingCode(phoneNumber)
    updateBotStatus({
      pairingCode: code,
      status: "Code de jumelage généré",
    })
    return code
  } catch (error) {
    console.error("Erreur demande code:", error)

    if (error.message.includes("not initialized")) {
      throw new Error("Bot non initialisé. Redémarrez le bot.")
    } else if (error.message.includes("invalid number")) {
      throw new Error("Numéro de téléphone invalide. Utilisez le format international (+33...)")
    } else {
      throw new Error("Impossible de générer le code. Vérifiez le numéro et réessayez.")
    }
  }
}

// Générer un QR code simulé avec SVG
function generateMockQRCode(): string {
  const size = 200
  const cellSize = 8
  const cells = size / cellSize

  let svg = `<svg width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg">`
  svg += `<rect width="100%" height="100%" fill="white"/>`

  // Générer un pattern aléatoire qui ressemble à un QR code
  for (let i = 0; i < cells; i++) {
    for (let j = 0; j < cells; j++) {
      // Coins fixes (comme un vrai QR code)
      if ((i < 7 && j < 7) || (i < 7 && j > cells - 8) || (i > cells - 8 && j < 7) || Math.random() > 0.5) {
        svg += `<rect x="${i * cellSize}" y="${j * cellSize}" width="${cellSize}" height="${cellSize}" fill="black"/>`
      }
    }
  }

  svg += "</svg>"

  return `data:image/svg+xml;base64,${btoa(svg)}`
}

// Fonction pour traiter les commandes
export async function processCommand(command: string, userId = "demo-user", userName = "Testeur") {
  if (!pokemonGame) {
    return "❌ Bot non démarré"
  }

  const cmd = command.toLowerCase().substring(1) // Enlever le !
  const parts = command.split(" ")

  let response = ""

  try {
    switch (cmd) {
      case "start":
        response = pokemonGame.startPlayer(userId, userName)
        break

      case "profile":
        response = pokemonGame.getProfile(userId)
        break

      case "catch":
        response = pokemonGame.catchPokemon(userId)
        break

      case "pokemon":
        response = pokemonGame.getPokemonList(userId)
        break

      case "release":
        const pokemonName = parts.slice(1).join(" ")
        response = pokemonGame.releasePokemon(userId, pokemonName)
        break

      case "wild":
        response = pokemonGame.wildBattle(userId)
        break

      case "bag":
        response = pokemonGame.getBag(userId)
        break

      case "use":
        const item = parts.slice(1).join(" ")
        response = pokemonGame.useItem(userId, item)
        break

      case "shop":
        response = pokemonGame.getShop()
        break

      case "buy":
        const buyItem = parts.slice(1).join(" ")
        response = pokemonGame.buyItem(userId, buyItem)
        break

      case "stats":
        const statsPokemon = parts.slice(1).join(" ")
        response = pokemonGame.getPokemonStats(userId, statsPokemon)
        break

      case "leaderboard":
        response = pokemonGame.getLeaderboard()
        break

      case "help":
        response = getHelpMessage()
        break

      default:
        response = "❓ Commande inconnue. Tapez !help pour voir toutes les commandes."
    }

    return response
  } catch (error) {
    console.error("Erreur commande Pokemon:", error)
    return "❌ Une erreur est survenue lors de l'exécution de la commande."
  }
}

function getHelpMessage(): string {
  return `🎮 *POKÉBOT - GUIDE COMPLET*

*🎯 Commandes de base:*
!start - Commencer votre aventure Pokémon
!profile - Voir votre profil de dresseur
!catch - Capturer un Pokémon sauvage
!pokemon - Voir vos Pokémon capturés
!release [nom] - Relâcher un Pokémon

*⚔️ Combat:*
!wild - Combattre un Pokémon sauvage

*🎒 Inventaire:*
!bag - Voir votre sac d'objets
!use [objet] - Utiliser un objet
!shop - Voir la boutique Pokémon
!buy [objet] - Acheter un objet

*📊 Informations:*
!stats [pokémon] - Voir les stats d'un Pokémon
!leaderboard - Classement des dresseurs
!help - Afficher cette aide

*Bon jeu, Dresseur! 🌟*`
}
