import { Client, LocalAuth } from "whatsapp-web.js"
import qrcode from "qrcode"
import { PokemonGame } from "./pokemon-game"

let client: Client | null = null
let eventListeners: ((data: any) => void)[] = []
let pokemonGame: PokemonGame

// Émetteur d'événements pour le frontend
export function getEventStream() {
  const encoder = new TextEncoder()

  return new ReadableStream({
    start(controller) {
      const listener = (data: any) => {
        const message = `data: ${JSON.stringify(data)}\n\n`
        controller.enqueue(encoder.encode(message))
      }

      eventListeners.push(listener)

      // Heartbeat pour maintenir la connexion
      const heartbeat = setInterval(() => {
        controller.enqueue(encoder.encode('data: {"type":"heartbeat"}\n\n'))
      }, 30000)

      return () => {
        eventListeners = eventListeners.filter((l) => l !== listener)
        clearInterval(heartbeat)
      }
    },
  })
}

function emitEvent(data: any) {
  eventListeners.forEach((listener) => listener(data))
}

export async function startWhatsAppBot() {
  if (client) {
    await client.destroy()
  }

  pokemonGame = new PokemonGame()

  client = new Client({
    authStrategy: new LocalAuth({
      clientId: "pokemon-bot",
    }),
    puppeteer: {
      headless: true,
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-accelerated-2d-canvas",
        "--no-first-run",
        "--no-zygote",
        "--single-process",
        "--disable-gpu",
      ],
    },
  })

  // Événement QR Code
  client.on("qr", async (qr) => {
    try {
      const qrCodeDataURL = await qrcode.toDataURL(qr)
      emitEvent({ type: "qr", qr: qrCodeDataURL })
    } catch (error) {
      console.error("Erreur génération QR:", error)
    }
  })

  // Événement code de jumelage
  client.on("code", (code) => {
    emitEvent({ type: "code", code })
  })

  // Bot prêt
  client.on("ready", () => {
    console.log("Bot WhatsApp connecté!")
    emitEvent({ type: "ready" })
  })

  // Déconnexion
  client.on("disconnected", (reason) => {
    console.log("Bot déconnecté:", reason)
    emitEvent({ type: "disconnected", reason })
  })

  // Gestion des messages
  client.on("message", async (message) => {
    if (message.body.startsWith("!")) {
      await handlePokemonCommand(message)
    }
  })

  await client.initialize()
}

export async function stopWhatsAppBot() {
  if (client) {
    await client.destroy()
    client = null
    emitEvent({ type: "disconnected" })
  }
}

export async function requestPairingCode(phoneNumber: string) {
  if (client) {
    try {
      const code = await client.requestPairingCode(phoneNumber)
      emitEvent({ type: "code", code })
    } catch (error) {
      console.error("Erreur demande code:", error)
    }
  }
}

async function handlePokemonCommand(message: any) {
  const command = message.body.toLowerCase().split(" ")
  const cmd = command[0].substring(1) // Enlever le !
  const userId = message.from
  const userName = message._data.notifyName || "Dresseur"

  let response = ""

  try {
    switch (cmd) {
      case "start":
        response = pokemonGame.startPlayer(userId, userName)
        break

      case "profile":
        response = pokemonGame.getProfile(userId)
        break

      case "catch":
        response = pokemonGame.catchPokemon(userId)
        break

      case "pokemon":
        response = pokemonGame.getPokemonList(userId)
        break

      case "release":
        const pokemonName = command.slice(1).join(" ")
        response = pokemonGame.releasePokemon(userId, pokemonName)
        break

      case "battle":
        const mention = message.mentionedIds[0]
        if (mention) {
          response = pokemonGame.challengePlayer(userId, mention)
        } else {
          response = "❌ Mentionnez un joueur pour le défier: !battle @joueur"
        }
        break

      case "accept":
        response = pokemonGame.acceptBattle(userId)
        break

      case "attack":
        const move = command.slice(1).join(" ")
        response = pokemonGame.attack(userId, move)
        break

      case "wild":
        response = pokemonGame.wildBattle(userId)
        break

      case "bag":
        response = pokemonGame.getBag(userId)
        break

      case "use":
        const item = command.slice(1).join(" ")
        response = pokemonGame.useItem(userId, item)
        break

      case "shop":
        response = pokemonGame.getShop()
        break

      case "buy":
        const buyItem = command.slice(1).join(" ")
        response = pokemonGame.buyItem(userId, buyItem)
        break

      case "stats":
        const statsPokemon = command.slice(1).join(" ")
        response = pokemonGame.getPokemonStats(userId, statsPokemon)
        break

      case "leaderboard":
        response = pokemonGame.getLeaderboard()
        break

      case "trade":
        const tradeMention = message.mentionedIds[0]
        if (tradeMention) {
          response = pokemonGame.initiateTrade(userId, tradeMention)
        } else {
          response = "❌ Mentionnez un joueur pour échanger: !trade @joueur"
        }
        break

      case "help":
        response = getHelpMessage()
        break

      default:
        response = "❓ Commande inconnue. Tapez !help pour voir toutes les commandes."
    }

    if (response) {
      await message.reply(response)
    }
  } catch (error) {
    console.error("Erreur commande Pokemon:", error)
    await message.reply("❌ Une erreur est survenue lors de l'exécution de la commande.")
  }
}

function getHelpMessage(): string {
  return `🎮 *POKÉBOT - GUIDE COMPLET*

*🎯 Commandes de base:*
!start - Commencer votre aventure Pokémon
!profile - Voir votre profil de dresseur
!catch - Capturer un Pokémon sauvage
!pokemon - Voir vos Pokémon capturés
!release [nom] - Relâcher un Pokémon

*⚔️ Combat:*
!battle @joueur - Défier un autre dresseur
!accept - Accepter un défi de combat
!attack [attaque] - Attaquer pendant un combat
!wild - Combattre un Pokémon sauvage

*🎒 Inventaire:*
!bag - Voir votre sac d'objets
!use [objet] - Utiliser un objet
!shop - Voir la boutique Pokémon
!buy [objet] - Acheter un objet

*📊 Informations:*
!stats [pokémon] - Voir les stats d'un Pokémon
!leaderboard - Classement des dresseurs
!trade @joueur - Échanger avec un joueur
!help - Afficher cette aide

*Bon jeu, Dresseur! 🌟*`
}
